﻿Public Enum LogEventType
    information
    message
    warning
    errors
    debug

    all

End Enum
