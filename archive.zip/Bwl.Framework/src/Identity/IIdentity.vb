﻿Public Interface IIdentity
    Property ID As String
End Interface
