﻿Public Interface IDescription
    Property Description As String
    Property Type As String
End Interface
