﻿Public Interface IUIElementRemote
    Inherits IUIElement

End Interface
