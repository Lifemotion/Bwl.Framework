﻿Public Interface IUIElementLocal
    Inherits IUIElement
    Sub SendUpdate()
End Interface
